#include <iostream>
#include <iomanip>
#include <random>
#include <ranges>
#include <vector>

#include "Mapp.h"

using namespace std;

//https://www.daniweb.com/programming/software-development/threads/135010/map-function-pointer
//https://stackoverflow.com/questions/53755459/how-to-dereference-a-pointer-to-a-map-of-pointers-to-objects-in-c


//Want to get the value of an ALU arithmatic function from the map by passing the key(add, movq, subtract, etc)
//And getting the function pointer to pass( register/immediate value , register/immediate value ) and return the value,
int main(){
    // std::map<std::string, Mapp *>   *Mapplist;
    // std::map<std::string, Mapp *>    Mappwanted;
    // Mapplist = &Mappwanted;

    Mapp map;
    string assembly_op = "add"; //dummy, changed based on line read 

    //int (*funcptr)(int,int);

//Random Code;
    // (*Mapplist)["add"] = new Mapp;
    // int value;
    // funcptr = Mapplist["add"] ;
    // cout << funcptr(&reg_a,&reg_b);
    //funcptr;//(reg_a,reg_b);
    //int (AL::*funcptr)(int,int) = map.reg["add"]; // funcptr["add"](reg_a, reg_b);


//Try 1 ----------
/*
    int reg_a = 4, reg_b = 2;
    //Needed the parent function^^
    Mapp* map2;
    map2->reg[assembly_op](reg_a,reg_b); //dereference 
    auto func = map2->reg[assembly_op];
 
    int value = (*func)(reg_a,reg_b);
    //func(1,2);
    cout << value;
//Error:   constexpr pair(const pair&) = default;    ///< Copy constructor, expects 1 argument, 2 provided
*/


//Try 2 -----
/*
//https://stackoverflow.com/questions/2136998/using-a-stl-map-of-function-pointers
    int value;
    auto iter = map.reg.find(assembly_op);
    if(iter == map.reg.end()){
        cout << "not found\n";
    }else{
        value = (*iter->second)(reg_a,reg_b);
    }

    cout << value;
    
//Error:   constexpr pair(const pair&) = default;    ///< Copy constructor, expects 1 argument, 2 provided
*/

    return 0;
}