#ifndef AL_H
#define AL_H

#include <iostream>
#include <iomanip>
#include <iostream>
#include <iomanip>

using namespace std;

//dummy ALU
class AL{
private:

public:
    // AL(/* args */);
    // ~AL();

    int add(int a, int b){
        cout << "here\n";
        return a+b;
    }
    int sub(int a, int b){
        return a-b;
    }
    int mult(int a, int b){
        return a*b;
    }
};


#endif