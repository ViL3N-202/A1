#ifndef MAPP_H
#define MAPP_H

#include <map>
#include <string>
#include <iostream>
#include <unordered_map>

#include "AL.cpp"

using namespace std; 

//Dummy register file
class Mapp: public AL{
private:

public:
//https://www.daniweb.com/programming/software-development/threads/135010/map-function-pointer
//https://stackoverflow.com/questions/2136998/using-a-stl-map-of-function-pointers
    
    typedef int (*func)(int,int);
    // typedef map<string,func> reg;

    unordered_map<string, func> reg;
    //map<string, func> reg;

    //map<string, int (AL::*)(int, int)> reg;
    //funct pointer type Parent class ?

    Mapp();
    ~Mapp();
};

#endif