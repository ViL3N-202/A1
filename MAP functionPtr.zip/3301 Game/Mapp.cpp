#include "Mapp.h"

Mapp::Mapp(/* args */){
    // reg["add"] = &add;
    // reg["sub"] = &sub;
    // reg["mult"] = &mult;

    reg.emplace("mult", &mult);
    reg.emplace("add", &add);
    reg.emplace("sub", &sub);
}

Mapp::~Mapp(){}
